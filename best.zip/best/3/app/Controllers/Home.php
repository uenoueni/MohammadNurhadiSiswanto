<?php

namespace App\Controllers;

class Home extends BaseController
{   
    protected $db;
    function __construct()
    {
        $this->db = db_connect();
    }
    public function index()
    {
        return view('karyawan');
    }
    function create(){
        $data['nama'] = $this->getPost('nama');
        $data['jenis_kelamin'] = $this->getPost('jenis_kelamin');
        $data['alamat'] = $this->getPost('alamat');

        $r = $this->db->table('karyawan')
            ->insert($data);
        if($r){
            $response = [
                'status' => "200",
                'messages' => "Berhasil"
            ];
        }else{
            $response = [
                'status' => "401",
                'messages' => "oops"
            ];
        }
        return $this->response->setJSON($response);
    }
    function update(){
        $data['id'] = $this->getPost('id');
        $data['nama'] = $this->getPost('nama');
        $data['jenis_kelamin'] = $this->getPost('jenis_kelamin');
        $data['alamat'] = $this->getPost('alamat');

        $r = $this->db->table('karyawan')
            ->where(['id' => $this->getPost('id')])
            ->update($data);
            
        if($r){
            $response = [
                'status' => "200",
                'messages' => "Berhasil"
            ];
        }else{
            $response = [
                'status' => "401",
                'messages' => "Oops"
            ];
        }
        return $this->response->setJSON($response);
    }
    function read($id){
        
        $r = $this->db->table('karyawan')
            ->select("*")
            ->where(['id' => $id])->get()->getResult()[0];
            
        if($r){
            $response = [
                'status' => "200",
                'data' => $r
            ];
        }else{
            $response = [
                'status' => "401",
                'messages' => "Oops"
            ];
        }
        return $this->response->setJSON($response);
    }
}
